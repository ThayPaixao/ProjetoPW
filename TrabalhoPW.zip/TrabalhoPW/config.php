<?php 


$host = "localhost";
$banco = "bdatividade";
$user = "root";
$senha_user = "";

$con = mysqli_connect($host, $user, $senha_user, $banco);

?>
