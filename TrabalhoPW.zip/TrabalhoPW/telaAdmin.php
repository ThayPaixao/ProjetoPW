<?php
    session_start();
    include_once('config.php');

    if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['password']) == true)) {
             
        unset($_SESSION['email']);
        unset($_SESSION['password']);
        header('locacion: telaLogin.php');
    }

    $logado = $_SESSION['email'];

    $sql = "SELECT * FROM usuario ORDER BY Email DESC";

    $rs = $con->query($sql);
?>

<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Extra.css">
    <title>Meu Site</title>

    <script src="https://kit.fontawesome.com/e2d59dab98.js" crossorigin="anonymous"></script>
    <script>
        function exibirAlerta() {
            alert('Desculpe, está pagina ainda está em progresso...');
        }
    </script>

    
</head>
<body>

    <header>
        <nav>
            <div class="logo">
            <ul class="menu">    
                <li><a href="indexa.php"><i class="fa-solid fa-anchor fa-lg"></i></a></li>
                <li><a href="" onclick="exibirAlerta()" >Sobre Nós</a></li>
            </ul>
            </div>
            <ul class="menu">
                
                <li class="login"><a href=""><i class="fa-solid fa-circle-user fa-xl"></i></a></li>
            </ul>
        </nav>
    </header>

    <div>
        <table class="lista">
            <thead>
                <th> Email </th>
                <th> Nome</th>
                <th> Sobrenome</th>
                <th> Usuario </th>
                <th> ... </th>
            </thead>
            <tbody> 
                <?php
                    while($user_data = mysqli_fetch_assoc($rs))
                    {
                        echo "<tr>";
                        echo "<td>" . $user_data['Email'] . "</td>";
                        echo "<td>" . $user_data['Nome'] . "</td>";
                        echo "<td>" . $user_data['Sobrenome'] . "</td>";
                        echo "<td>" . $user_data['Usuario'] . "</td>";
                        echo "<td> <a  class='icone' href='telaEditar.php?Email=$user_data[Email])'><i class='fa-solid fa-pencil'></i> </a> <a href='#' class='icone2'><i class='fa-solid fa-x'></i></a></td>";
                        echo "</tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>

    </body>
</html>