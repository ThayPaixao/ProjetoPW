<?php
    if(!empty($_GET['Email'])) {

        include_once('config.php');

        $email = $_GET['Email'];

        $sqlSelect = "SELECT * FROM usuario WHERE Email='$email'";

        $rs = $con->query($sqlSelect);

        if($rs->num_rows > 0) {
            while($user_data = mysqli_fetch_assoc($rs)) {
            $nome = $user_data['name'];
            $sobrenome = $user_data['surname'];
            $usuario = $user_data['username'];
            $senha = $user_data['password'];
            }

        } else {
            header("location: telaAdmin.php");
        }

    }

?>     

<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Menu.css">
    <title>Meu Site</title>

    <script src="https://kit.fontawesome.com/e2d59dab98.js" crossorigin="anonymous"></script>
    <script>
        function exibirAlerta() {
            alert('Desculpe, está pagina ainda está em progresso...');
        }

        function alertCadastro() {
            alert('Usuário Cadastrado!');
        }
    </script>
</head>
<style>
    Body {
        background-image: url("fundoSN.png");
        background-size: cover;
        background-attachment: fixed;
    }
</style>
<body>

    <header>
        <nav>
            <div class="logo">
            <ul class="menu">    
                <li><a href="index.php"><i class="fa-solid fa-anchor fa-lg"></i></a></li>
                <li><a href="" onclick="exibirAlerta()" >Sobre Nós</a></li>
            </ul>
            </div>
            <ul class="menu">
                
                <li class="login"><a href=""><i class="fa-solid fa-circle-user fa-xl"></i></a></li>
            </ul>
        </nav>
    </header>

    <section class="conteudo">
        <div class="register-form">
            <h2>Faça Login</h2>
            <form action="phpCadastro.php" method="POST" id="loginForm">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" value="<?php echo $email ?>" required>

                <label for="name">Nome</label>
                <input type="text" id="name" name="name" value="<?php echo $nome ?>" required>

                <label for="surname">Sobrenome</label>
                <input type="text" id="surname" name="surname" value="<?php echo $sobrenome ?>" required>

                <label for="username">Nome de Usuário</label>
                <input type="text" id="username" name="username" value="<?php echo $usuario ?>" required>

                <label for="password">Senha</label>
                <input type="password" id="password" name="password" value="<?php echo $senha ?>" required>

                <button type="submit" class="btnf" name="cadastrar" id="cadastrar" onclick="alertCadastro()">Cadastrar</button>
            </form>
        </div>
    </section>