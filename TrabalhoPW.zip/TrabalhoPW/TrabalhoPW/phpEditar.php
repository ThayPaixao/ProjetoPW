<?php 
    include_once('config.php');

    if(isset($_POST['atualizar'])) {
        $id = $_POST["id"];
        $email = $_POST["email"];
        $nome = $_POST["name"];
        $sobrenome = $_POST["surname"];
        $usuario = $_POST["username"];
        $senha = $_POST["password"];

        $sqlUpdate = "UPDATE usuario SET Email='$email', Nome='$nome', Sobrenome='$sobrenome', Usuario='$usuario', Senha='$senha' WHERE Id='$id'";

        $rs = $con->query($sqlUpdate);        

    }

    header("Location: telaAdmin.php");

?>