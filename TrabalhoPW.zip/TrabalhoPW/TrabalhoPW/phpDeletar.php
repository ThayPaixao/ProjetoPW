<?php

    if(!empty($_GET['Id'])) {

        include_once('config.php');

        $id = $_GET['Id'];

        $sqlSelect = "SELECT * FROM usuario WHERE Id='$id'";

        $rs = $con->query($sqlSelect);

        if($rs->num_rows > 0) {

            $sqlDelete = "DELETE FROM usuario WHERE Id='$id'";
            $rsDelete = $con->query($sqlDelete);
            
        }

        header("location: telaAdmin.php");
    }
?>