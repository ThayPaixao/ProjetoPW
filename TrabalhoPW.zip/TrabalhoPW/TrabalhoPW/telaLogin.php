<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Menu.css">
    <title>Meu Site</title>

    <script src="https://kit.fontawesome.com/e2d59dab98.js" crossorigin="anonymous"></script>
    <script>
        function exibirAlerta() {
            alert('Desculpe, está pagina ainda está em progresso...');
        }
    </script>
</head>
<style>
    Body {
        background-image: url("fundoSN.png");
        background-size: cover;
        background-attachment: fixed;
    }
</style>
<body>

    <header>
        <nav>
            <div class="logo">
            <ul class="menu">    
                <li><a href="index.php"><i class="fa-solid fa-anchor fa-lg"></i></a></li>
                <li><a href="" onclick="exibirAlerta()" >Sobre Nós</a></li>
            </ul>
            </div>
            <ul class="menu">
                
                <li class="login"><a href=""><i class="fa-solid fa-circle-user fa-xl"></i></a></li>
            </ul>
        </nav>
    </header>

    <section class="conteudo">
        <div class="login-form">
            <h2>Faça Login</h2>
            <form id="loginForm" action="phpLogar.php" method="POST">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" required>

                <label for="password">Senha</label>
                <input type="password" id="password" name="password" required>

                <button type="submit" class="btnf" name="logar" id="logar">Entrar</button>
            </form>
            <h6> Não tem uma conta? <a href="telaCadastro.php" class="af"> Cadastre-se agora. </a></h6>
        </div>
    </section>

</body>
</html>