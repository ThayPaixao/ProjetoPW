<?php
    if(isset($_POST['cadastrar'])) {
        $email = $_POST["email"];
        $nome = $_POST["name"];
        $sobrenome = $_POST["surname"];
        $usuario = $_POST["username"];
        $senha = $_POST["password"];
    }

    include_once('config.php');

    if(!$con) {
        die("conexão falhou." . mysqli_connect_error());
    }

    $sql = "INSERT INTO usuario (Email, Nome, Sobrenome, Usuario, Senha) VALUES('$email','$nome','$sobrenome','$usuario','$senha')";

    $rs = mysqli_query($con, $sql);

        echo "<a href='index.php'><input type='button' value='Voltar a pagina'></input></a>";
    ?>