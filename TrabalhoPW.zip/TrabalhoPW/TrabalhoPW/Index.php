<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Menu.css">
    <title>Meu Site</title>

    <script src="https://kit.fontawesome.com/e2d59dab98.js" crossorigin="anonymous"></script>
    <script>
        function exibirAlerta() {
            alert('Desculpe, está pagina ainda está em progresso...');
        }
    </script>

    
</head>
<body>

    <header>
        <nav>
            <div class="logo">
            <ul class="menu">    
                <li><a href=""><i class="fa-solid fa-anchor fa-lg"></i></a></li>
                <li><a href="" onclick="exibirAlerta()" >Sobre Nós</a></li>
            </ul>
            </div>
            <ul class="menu">
                
                <li class="login"><a href="telaLogin.php"><i class="fa-solid fa-circle-user fa-xl"></i></a></li>
            </ul>
        </nav>
    </header>

    <section class="conteudo">
        <div class="container">
            <div class="slide" id="slide1">
                <h1>. ○ ◌ ◦ . Bem-vindo ao Nosso Site! . ◦ ◌ ○ .</h1>
                <p> Atividade feita pelos alunos da ETEC Bento Qurino para a matéria de Programação Web.</p>
            </div>
        </div>
        <div class="container2">
            <div class="slide" id="slide2">
                <h1>Conheça Mais Sobre Nós</h1>
                <p> Descubra mais sobre que são os alunos e qual o intuito do Site. </p>
                <a href="" onclick="exibirAlerta()" class="btn">✦ Descubra Mais ✦</a>
            </div>
            <div class="slide" id="slide3">
                <h1>Junte-se a nós </h1>
                <p>Se Cadastre-se para poder receber Notificações e mais! </br> (Alguns recursos ainda não estão habilitados na versão Beta do site).</p>
                <a href="telaCadastro.php" class="btn"> ✦ Cadastre-se ✦ </a>
            </div>
        </div>
    </section>

</body>
</html>