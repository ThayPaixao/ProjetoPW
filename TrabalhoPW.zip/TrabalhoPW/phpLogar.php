<?php 
    session_start();

    if(isset($_POST['logar']) && !empty($_POST['email']) && !empty($_POST['password'])) {
        
        include_once('config.php');
        $email = $_POST['email'];
        $senha = $_POST['password'];

        print_r('Email: ' . $email);
        print_r('Senha: ' . $senha);

        $sql = "SELECT * FROM usuario WHERE email = '$email' and senha = '$senha'";
        
        $rs = $con->query($sql);
        
       // print_r($result);

       if(mysqli_num_rows($rs) <1) {

            unset($_SESSION['email']);
            unset($_SESSION['password']);
            header('location: telaLogin.php');
       } else {

            $_SESSION['email'] = $email;
            $_SESSION['password'] = $senha;

            if($email = 'admin@') {
                header('Location: telaAdmin.php');
            } else {
                header('Location: telaUsuario.php');
            }
       }

    } else {
        header('Location: telaLogin.php');
    }
?> 